# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate images original text with physical files.


$key = q/{inline}mboxbullet{inline}MSF=2.5;AAT;/;
$cached_env_img{$key} = q|<IMG
  ALIGN="BOTTOM" BORDER="0"
 SRC="img1.gif"
 ALT="$\mbox{$\bullet$}$">|; 

1;

